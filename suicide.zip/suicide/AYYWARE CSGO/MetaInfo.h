/*
Syn's AyyWare Framework
*/

#pragma once

#define AYYWARE_META_GAME "Counter-Strike: Global Offensive"
#define AYYWARE_META_CHEATVER "0.7"
#define AYYWARE_META_CHEATNAME "AYYWare for Counter-Strike: Global Offensive"

void PrintMetaHeader();