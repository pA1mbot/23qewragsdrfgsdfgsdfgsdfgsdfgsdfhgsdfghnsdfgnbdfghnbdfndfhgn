/*
Syn's AyyWare Framework 2015
*/

// Credits to Valve and Shad0w
#pragma once

void ApplyAAAHooks();