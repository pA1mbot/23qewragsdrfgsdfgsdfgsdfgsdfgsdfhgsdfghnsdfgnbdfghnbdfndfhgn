/*
Syn's AyyWare Framework 2015
*/

// Credits Valve / Shad0w

#pragma once

unsigned int CRC32(void *pData, size_t iLen);